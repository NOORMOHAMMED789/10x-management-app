const StudentsList = [
  {
    id: 1,
    name: "Mohammed",
    dept: "mech",
  },
  {
    id: 2,
    name: "Mohammed",
    dept: "mech",
  },
  {
    id: 3,
    name: "Mohammed",
    dept: "mech",
  },
  {
    id: 4,
    name: "Mohammed",
    dept: "mech",
  },
  {
    id: 5,
    name: "Noor",
    dept: "mech",
  },
  {
    id: 6,
    name: "Kolar",
    dept: "mech",
  },
];
